import React from "react";
import './loginpage.css'

const loginpage = ()=>{
    return(
        <body>
        <div className="a1"><h1>안녕하세요</h1></div>
        </body>
    )
}
export default loginpage;